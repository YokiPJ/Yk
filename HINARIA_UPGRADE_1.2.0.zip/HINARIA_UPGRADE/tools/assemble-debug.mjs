import { spawnSync } from 'node:child_process';
import { existsSync, copyFileSync, mkdirSync, readFileSync } from 'node:fs';
import { resolve, join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { javaTrustStore } from './java-trust.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const android=join(root,'android');
const win=process.platform === 'win32';
const gradlew=join(android,win?'gradlew.bat':'gradlew');
if (!existsSync(gradlew)) {
  console.error('Falta android/gradlew. Use npm run android:add na primeira vez.');
  process.exit(1);
}
const args=['--no-daemon','--max-workers=2'];
// Java/Gradle do not automatically honor HTTPS_PROXY. Reuse its host/port,
// keeping credentials in the platform proxy and TLS verification enabled.
const proxyValue=process.env.HTTPS_PROXY || process.env.HTTP_PROXY;
if (proxyValue) {
  const proxy=new URL(proxyValue);
  if (!['http:','https:'].includes(proxy.protocol)) throw new Error('Proxy HTTP/HTTPS necessário para Gradle.');
  const port=proxy.port || (proxy.protocol==='https:'?'443':'80');
  for (const scheme of ['http','https']) args.push(`-D${scheme}.proxyHost=${proxy.hostname}`,`-D${scheme}.proxyPort=${port}`);
  // Use the host's trusted CA store when available (includes managed proxy CA).
  // This retains full certificate verification for a separately installed JDK.
  const trustStore=javaTrustStore();
  if (trustStore && existsSync(trustStore)) args.push(`-Djavax.net.ssl.trustStore=${trustStore}`);
}
args.push('assembleDebug');
const r=spawnSync(gradlew,args,{cwd:android,stdio:'inherit',shell:win});
if (r.error) throw r.error;
if (r.status!==0) process.exit(r.status||1);
const apk=join(android,'app','build','outputs','apk','debug','app-debug.apk');
if (!existsSync(apk)) throw new Error('Gradle terminou sem encontrar app-debug.apk');
// Fail rather than handing over a stale APK produced from the previous web build.
const expected='1.1.0 · COMBATE MANUAL + VFX/SFX V2 · STORY';
const index=join(root,'android','app','src','main','assets','public','index.html');
if (!readFileSync(index,'utf8').includes(expected)) throw new Error('APK NAO ATUALIZADO: index.html offline sem marcador 1.1.0 Fase 1');
const unzip=spawnSync('unzip',['-p',apk,'assets/public/index.html'],{encoding:'utf8'});
if (unzip.status!==0 || !unzip.stdout.includes(expected)) throw new Error('APK NAO ATUALIZADO: nao consegui verificar a identidade 1.1.0 Fase 1 no APK final');
const build=JSON.parse(readFileSync(join(root,'www','build-info.json'),'utf8'));
const packedBuild=spawnSync('unzip',['-p',apk,'assets/public/build-info.json'],{encoding:'utf8'});
if (packedBuild.status!==0 || JSON.parse(packedBuild.stdout).fingerprint!==build.fingerprint)
  throw new Error('APK NAO ATUALIZADO: fingerprint web não corresponde ao APK final');

const target=join(root,'APK_GERADO','HINARIA_V7_DEBUG.apk');
mkdirSync(dirname(target),{recursive:true});
copyFileSync(apk,target);
const marked=join(root,'APK_GERADO','HINARIA_1_1_0_COMBATE_MANUAL_VFX.apk');
copyFileSync(apk,marked);
const upgraded=join(root,'APK_GERADO','HINARIA_UPGRADE_DEBUG.apk');
copyFileSync(apk,upgraded);
console.log('HINÁRIA upgrade APK: '+upgraded+' · fingerprint '+build.fingerprint);
console.log('APK novo, identificavel: '+marked);
console.log('Verifique na tela do jogo o texto 1.1.0 · COMBATE MANUAL + VFX/SFX V2 · STORY');
console.log('APK criado em: '+target);
