const fs = require('fs');
const path = require('path');

function getExports(filePath) {
    const content = fs.readFileSync(filePath, 'utf8');
    const exports = [];
    // Match: export const NAME =, export function NAME, export { NAME }
    const patterns = [
        /export\s+(?:const|function|class)\s+(\w+)/g,
        /export\s+\{([^}]+)\}/g,
    ];
    for (const pattern of patterns) {
        let match;
        while ((match = pattern.exec(content)) !== null) {
            if (match[1].includes(',')) {
                match[1].split(',').forEach(s => exports.push(s.trim()));
            } else {
                exports.push(match[1].trim());
            }
        }
    }
    return exports;
}

function getImports(filePath) {
    const content = fs.readFileSync(filePath, 'utf8');
    const imports = [];
    const pattern = /import\s+\{([^}]+)\}\s+from\s+['"]([^'"]+)['"]/g;
    let match;
    while ((match = pattern.exec(content)) !== null) {
        const names = match[1].split(',').map(s => s.trim().split(/\s+as\s+/)[0].trim());
        const from = match[2];
        for (const name of names) {
            imports.push({ name, from, file: filePath });
        }
    }
    // Also handle default imports
    const defaultPattern = /import\s+(\w+)\s+from\s+['"]([^'"]+)['"]/g;
    while ((match = defaultPattern.exec(content)) !== null) {
        imports.push({ name: match[1], from: match[2], file: filePath });
    }
    return imports;
}

const srcDir = 'src';
const files = [];
function walk(dir) {
    for (const f of fs.readdirSync(dir)) {
        const full = path.join(dir, f);
        if (fs.statSync(full).isDirectory()) walk(full);
        else if (f.endsWith('.js')) files.push(full);
    }
}
walk(srcDir);

// Build export map
const exportMap = {};
for (const f of files) {
    const rel = path.relative(srcDir, f).replace(/\\/g, '/');
    exportMap[rel] = getExports(f);
}

// Check imports
let hasErrors = false;
for (const f of files) {
    const imports = getImports(f);
    for (const imp of imports) {
        if (imp.from.startsWith('.')) {
            const resolved = path.resolve(path.dirname(f), imp.from);
            const rel = path.relative(srcDir, resolved).replace(/\\/g, '/') + '.js';
            const exports = exportMap[rel];
            if (exports && !exports.includes(imp.name)) {
                console.log('MISSING EXPORT:', imp.file, 'imports', imp.name, 'from', imp.from, 'but not exported');
                hasErrors = true;
            }
        }
    }
}

if (!hasErrors) {
    console.log('All imports match exports!');
}